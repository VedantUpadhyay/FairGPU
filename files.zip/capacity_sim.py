"""
Scheduler-Aware GPU Capacity Planner for LLM Inference
=======================================================
Paper 3 simulation: shows how scheduler choice (FCFS vs VG+Aging)
affects the minimum GPU fleet size needed to meet a P99 TTFT SLA.

Based on M/G/c queueing theory with empirical service rates
measured from FairGPU experiments on Nautilus GPU cluster.

Usage:
    python capacity_sim.py

Outputs:
    - capacity_results.json  (raw data)
    - capacity_table.txt     (LaTeX-ready table)
    - scheduler_savings.txt  (key findings)
"""

import math
import json
import itertools
from dataclasses import dataclass, asdict
from typing import Optional


# ─────────────────────────────────────────────────────────────
# Empirical service rates from FairGPU experiments
# (requests per second, measured on Nautilus A10 GPU)
# ─────────────────────────────────────────────────────────────

EMPIRICAL_MU = {
    # (model, scheduler) -> measured throughput (rps)
    # Source: FairGPU Nautilus experiments, June 2026
    ("opt-1.3b", "fcfs"):              7.472,
    ("opt-1.3b", "chunked_fcfs"):      8.228,
    ("opt-1.3b", "value_greedy"):      7.787,
    ("opt-1.3b", "value_greedy_aging"): 9.286,
    ("opt-6.7b", "fcfs"):              2.876,
    ("opt-6.7b", "value_greedy"):      2.760,
    ("opt-6.7b", "value_greedy_aging"): 1.517,  # saturated — not useful
}

# GPU hardware costs (USD per GPU-hour, cloud on-demand, mid-2026)
GPU_COST_PER_HOUR = {
    "A10":  1.20,   # NVIDIA A10 24GB — used in experiments
    "A100": 3.00,   # NVIDIA A100 80GB
    "H100": 3.93,   # NVIDIA H100 SXM5 (post AWS June 2025 cut)
}

# SLA target: P99 TTFT must be below this threshold (seconds)
SLA_P99_TTFT_SEC = 2.0   # 2000ms — matches FairGPU absolute threshold

# Coefficient of variation for service time (M/G/c input)
# Empirically estimated from prefill+decode time distribution
# Prefill is roughly deterministic given prompt length;
# decode varies with output length. CV ~0.7 is a reasonable estimate
# for mixed short/long output workloads.
CV_SERVICE_TIME = 0.7


# ─────────────────────────────────────────────────────────────
# M/G/c Queueing Model
# Approximation: Kingman's formula extended to M/G/c
# Uses the Cosmetatos (1976) approximation for P99 wait time
# ─────────────────────────────────────────────────────────────

def erlang_c(c: int, rho_total: float) -> float:
    """
    Erlang C formula: probability that an arriving customer
    must wait (all c servers are busy).

    Parameters
    ----------
    c        : number of servers (GPUs)
    rho_total: total offered load = lambda / mu (not per-server)

    Returns probability of waiting (0 to 1).
    """
    rho_per_server = rho_total / c
    if rho_per_server >= 1.0:
        return 1.0  # unstable — all arrivals wait

    # Compute P(0) denominator using Poisson and Erlang terms
    a = rho_total  # offered load = lambda / mu
    numerator = (a ** c) / math.factorial(c) * (1.0 / (1.0 - rho_per_server))

    denominator = sum(a**k / math.factorial(k) for k in range(c)) + numerator
    return numerator / denominator


def mgc_mean_wait(
    lam: float,
    mu: float,
    c: int,
    cv: float = CV_SERVICE_TIME,
) -> float:
    """
    Mean waiting time in M/G/c queue (seconds).
    Uses the Cosmetatos approximation:
        W_q ≈ C(c, rho) * (1 + cv^2) / 2 * (1 / (c*mu - lambda))

    Parameters
    ----------
    lam : arrival rate (requests/sec)
    mu  : per-server service rate (requests/sec per GPU)
    c   : number of servers (GPUs)
    cv  : coefficient of variation of service time

    Returns mean waiting time in queue (seconds).
    """
    rho_total = lam / mu          # total offered load
    rho_per = rho_total / c       # utilization per server

    if rho_per >= 1.0:
        return float('inf')       # unstable

    ec = erlang_c(c, rho_total)
    mean_service = 1.0 / mu       # mean service time per GPU

    # Kingman / Cosmetatos correction for general service times
    w_q = ec * (1.0 + cv**2) / 2.0 * mean_service / (1.0 - rho_per)
    return w_q


def mgc_p99_wait(
    lam: float,
    mu: float,
    c: int,
    cv: float = CV_SERVICE_TIME,
) -> float:
    """
    Approximate P99 waiting time in M/G/c queue.

    Uses the approximation:
        P(W > t) ≈ C(c,rho) * exp(-mu*(c - rho_total)*t)
    Solve for t at P(W>t) = 0.01:
        t_99 = -ln(0.01/C) / (mu*(c - rho_total))

    Returns P99 wait time in seconds (approximation).
    """
    rho_total = lam / mu
    rho_per = rho_total / c

    if rho_per >= 1.0:
        return float('inf')

    ec = erlang_c(c, rho_total)
    if ec <= 0.01:
        return 0.0   # virtually no waiting

    # Exponential tail approximation
    decay = mu * (c - rho_total)
    if decay <= 0:
        return float('inf')

    # Apply (1 + cv^2)/2 correction for general service times
    correction = (1.0 + cv**2) / 2.0
    t99 = -math.log(0.01 / (ec * correction)) / decay
    return max(0.0, t99)


# ─────────────────────────────────────────────────────────────
# Capacity planning function
# ─────────────────────────────────────────────────────────────

@dataclass
class CapacityResult:
    model: str
    scheduler: str
    lambda_rps: float
    mu_rps: float
    rho_single: float           # utilization with 1 GPU
    min_gpus: int               # minimum GPUs to meet SLA
    p99_wait_ms: float          # P99 wait at min_gpus
    utilization_pct: float      # GPU utilization at min_gpus
    gpu_type: str
    cost_per_hour: float        # total fleet cost/hour
    cost_per_month: float       # total fleet cost/month
    sla_met: bool


def find_min_gpus(
    lam: float,
    mu: float,
    sla_sec: float = SLA_P99_TTFT_SEC,
    max_gpus: int = 20,
) -> tuple[int, float]:
    """
    Find minimum number of GPUs (c) such that P99 TTFT <= sla_sec.
    Returns (min_gpus, p99_wait_sec).
    """
    for c in range(1, max_gpus + 1):
        rho_per = (lam / mu) / c
        if rho_per >= 1.0:
            continue   # unstable with c GPUs, try more
        p99 = mgc_p99_wait(lam, mu, c)
        if p99 <= sla_sec:
            return c, p99
    return max_gpus, float('inf')


def plan_capacity(
    model: str,
    scheduler: str,
    lambda_rps: float,
    gpu_type: str = "A10",
    sla_sec: float = SLA_P99_TTFT_SEC,
) -> Optional[CapacityResult]:
    """
    Compute minimum GPU fleet for given model+scheduler+traffic.
    """
    mu = EMPIRICAL_MU.get((model, scheduler))
    if mu is None:
        return None

    rho_single = lambda_rps / mu
    min_gpus, p99_wait = find_min_gpus(lambda_rps, mu, sla_sec)

    sla_met = p99_wait <= sla_sec and p99_wait < float('inf')
    utilization = (lambda_rps / mu) / min_gpus * 100.0

    cost_hr = EMPIRICAL_MU.get((model, scheduler), 0)   # reuse lookup
    gpu_cost = GPU_COST_PER_HOUR.get(gpu_type, 1.20)
    cost_hour = min_gpus * gpu_cost
    cost_month = cost_hour * 24 * 30

    return CapacityResult(
        model=model,
        scheduler=scheduler,
        lambda_rps=lambda_rps,
        mu_rps=mu,
        rho_single=rho_single,
        min_gpus=min_gpus,
        p99_wait_ms=p99_wait * 1000.0,
        utilization_pct=utilization,
        gpu_type=gpu_type,
        cost_per_hour=cost_hour,
        cost_per_month=cost_month,
        sla_met=sla_met,
    )


# ─────────────────────────────────────────────────────────────
# Main analysis
# ─────────────────────────────────────────────────────────────

def run_analysis():
    results = []
    savings = []

    models = ["opt-1.3b", "opt-6.7b"]
    schedulers_1b = ["fcfs", "chunked_fcfs",
                     "value_greedy", "value_greedy_aging"]
    schedulers_67b = ["fcfs", "value_greedy"]

    # Sweep arrival rates
    lambdas_1b = [2, 4, 6, 7, 8, 9, 10, 12, 15]
    lambdas_67b = [1, 2, 3, 4, 5]

    gpu_type = "A10"

    print("=" * 72)
    print("SCHEDULER-AWARE GPU CAPACITY PLANNER — FairGPU Paper 3")
    print("=" * 72)
    print(f"SLA target: P99 TTFT <= {SLA_P99_TTFT_SEC*1000:.0f}ms")
    print(f"GPU type: {gpu_type} @ ${GPU_COST_PER_HOUR[gpu_type]:.2f}/hr")
    print()

    # ── opt-1.3b analysis ──────────────────────────────────────
    print("─" * 72)
    print("opt-1.3b: Minimum GPUs to Meet P99 TTFT SLA")
    print("─" * 72)
    print(f"{'λ (rps)':<10} {'FCFS GPUs':<12} {'VG+Aging GPUs':<16} "
          f"{'GPU Saved':<12} {'$/month saved':<15}")
    print("-" * 65)

    for lam in lambdas_1b:
        r_fcfs = plan_capacity("opt-1.3b", "fcfs", lam, gpu_type)
        r_vga  = plan_capacity("opt-1.3b", "value_greedy_aging",
                               lam, gpu_type)
        if r_fcfs and r_vga:
            results.append(asdict(r_fcfs))
            results.append(asdict(r_vga))
            saved_gpus = r_fcfs.min_gpus - r_vga.min_gpus
            saved_monthly = (r_fcfs.cost_per_month
                             - r_vga.cost_per_month)
            fcfs_label = (f"{r_fcfs.min_gpus}"
                          + ("*" if not r_fcfs.sla_met else ""))
            vga_label  = (f"{r_vga.min_gpus}"
                          + ("*" if not r_vga.sla_met else ""))
            savings_label = (f"-{saved_gpus}"
                             if saved_gpus > 0 else "0")
            money_label = (f"-${saved_monthly:,.0f}"
                           if saved_monthly > 0 else "$0")
            print(f"{lam:<10} {fcfs_label:<12} {vga_label:<16} "
                  f"{savings_label:<12} {money_label:<15}")
            if saved_gpus > 0:
                savings.append({
                    "lambda_rps": lam,
                    "model": "opt-1.3b",
                    "fcfs_gpus": r_fcfs.min_gpus,
                    "vga_gpus": r_vga.min_gpus,
                    "gpus_saved": saved_gpus,
                    "monthly_savings_usd": saved_monthly,
                    "annual_savings_usd": saved_monthly * 12,
                })

    print("* = SLA not met even at max GPUs tested")
    print()

    # ── opt-1.3b full comparison table ────────────────────────
    print("─" * 72)
    print("opt-1.3b at λ=10 rps: All Schedulers Compared")
    print("─" * 72)
    print(f"{'Scheduler':<22} {'μ (rps)':<10} {'Min GPUs':<10} "
          f"{'P99 TTFT':<12} {'Util%':<8} {'$/month':<10}")
    print("-" * 72)

    for sched in schedulers_1b:
        r = plan_capacity("opt-1.3b", sched, 10.0, gpu_type)
        if r:
            results.append(asdict(r))
            sla_mark = "✓" if r.sla_met else "✗"
            print(f"{sched:<22} {r.mu_rps:<10.3f} "
                  f"{r.min_gpus}{sla_mark:<9} "
                  f"{r.p99_wait_ms:<12.1f} "
                  f"{r.utilization_pct:<8.1f} "
                  f"${r.cost_per_month:,.0f}")

    print()

    # ── opt-6.7b analysis ──────────────────────────────────────
    print("─" * 72)
    print("opt-6.7b at various λ: Saturation Boundary")
    print("─" * 72)
    print(f"{'λ (rps)':<10} {'FCFS GPUs':<12} {'ρ/GPU':<10} "
          f"{'P99 TTFT':<14} {'SLA met?':<10}")
    print("-" * 56)

    for lam in lambdas_67b:
        r = plan_capacity("opt-6.7b", "fcfs", lam, gpu_type)
        if r:
            results.append(asdict(r))
            rho_label = f"{r.rho_single:.2f}"
            p99_label = (f"{r.p99_wait_ms:.0f}ms"
                         if r.p99_wait_ms < 1e6
                         else "∞")
            sla_label = "✓" if r.sla_met else "✗ saturated"
            print(f"{lam:<10} {r.min_gpus:<12} {rho_label:<10} "
                  f"{p99_label:<14} {sla_label}")

    print()

    # ── Scheduler savings summary ──────────────────────────────
    print("=" * 72)
    print("SCHEDULER SAVINGS SUMMARY (opt-1.3b, A10 GPU)")
    print("=" * 72)
    if savings:
        for s in savings:
            print(f"  λ={s['lambda_rps']} rps: "
                  f"VG+Aging saves {s['gpus_saved']} GPU "
                  f"vs FCFS → "
                  f"${s['monthly_savings_usd']:,.0f}/month, "
                  f"${s['annual_savings_usd']:,.0f}/year")
    else:
        print("  No GPU savings at tested traffic levels.")
        print("  (Both schedulers need same fleet size "
              "at these arrival rates)")

    # ── Key finding ───────────────────────────────────────────
    print()
    print("─" * 72)
    print("KEY FINDING")
    print("─" * 72)
    mu_fcfs = EMPIRICAL_MU[("opt-1.3b", "fcfs")]
    mu_vga  = EMPIRICAL_MU[("opt-1.3b", "value_greedy_aging")]
    improvement = (mu_vga - mu_fcfs) / mu_fcfs * 100
    print(f"  VG+Aging effective throughput: {mu_vga:.3f} rps")
    print(f"  FCFS effective throughput:     {mu_fcfs:.3f} rps")
    print(f"  Improvement: +{improvement:.1f}%")
    print()
    print(f"  The single-GPU operating range extends from:")
    print(f"    FCFS:     λ < {mu_fcfs:.1f} rps")
    print(f"    VG+Aging: λ < {mu_vga:.1f} rps")
    print()
    window = mu_vga - mu_fcfs
    cost_per_gpu_month = GPU_COST_PER_HOUR["A10"] * 24 * 30
    print(f"  Traffic window where VG+Aging saves 1 GPU:")
    print(f"    {mu_fcfs:.1f} < λ < {mu_vga:.1f} rps "
          f"({window:.2f} rps wide)")
    print(f"  Cost of 1 A10 GPU: "
          f"${cost_per_gpu_month:,.0f}/month, "
          f"${cost_per_gpu_month*12:,.0f}/year")
    print()
    print(f"  Operators running in this window can defer hardware")
    print(f"  procurement by deploying VG+Aging scheduler instead.")

    # ── LaTeX table output ────────────────────────────────────
    latex = generate_latex_table(lambdas_1b)
    print()
    print("─" * 72)
    print("LaTeX TABLE (paste into paper)")
    print("─" * 72)
    print(latex)

    # ── Save results ──────────────────────────────────────────
    output = {
        "metadata": {
            "sla_p99_ttft_ms": SLA_P99_TTFT_SEC * 1000,
            "gpu_type": "A10",
            "gpu_cost_per_hour": GPU_COST_PER_HOUR["A10"],
            "empirical_mu": {
                str(k): v for k, v in EMPIRICAL_MU.items()
            },
        },
        "results": results,
        "savings": savings,
    }

    with open("capacity_results.json", "w") as f:
        json.dump(output, f, indent=2)

    with open("capacity_table.tex", "w") as f:
        f.write(latex)

    print()
    print("Saved: capacity_results.json, capacity_table.tex")
    return output


def generate_latex_table(lambdas: list) -> str:
    """Generate LaTeX table for the paper."""
    lines = []
    lines.append(r"\begin{table*}[t]")
    lines.append(r"\centering")
    lines.append(
        r"\caption{Scheduler-aware GPU capacity planning for "
        r"\texttt{opt-1.3b} on A10 GPU (\$1.20/hr). "
        r"Minimum GPU count to meet P99 TTFT $\leq$ 2{,}000\,ms SLA. "
        r"VG+Aging extends the single-GPU operating range "
        r"from $\lambda < 7.5$\,rps to $\lambda < 9.3$\,rps, "
        r"saving one GPU for traffic in that window.}"
    )
    lines.append(r"\label{tab:capacity}")
    lines.append(r"\small")
    lines.append(r"\begin{tabular}{lrrrrr}")
    lines.append(r"\toprule")
    lines.append(
        r"$\lambda$ (rps) & \fcfs\ GPUs & \vga\ GPUs & "
        r"GPUs saved & \$/month saved & "
        r"\fcfs\ util\% \\"
    )
    lines.append(r"\midrule")

    for lam in lambdas:
        r_fcfs = plan_capacity("opt-1.3b", "fcfs", lam)
        r_vga  = plan_capacity("opt-1.3b", "value_greedy_aging", lam)
        if not r_fcfs or not r_vga:
            continue

        saved = r_fcfs.min_gpus - r_vga.min_gpus
        saved_money = r_fcfs.cost_per_month - r_vga.cost_per_month

        fcfs_str = str(r_fcfs.min_gpus)
        vga_str  = str(r_vga.min_gpus)
        if not r_fcfs.sla_met:
            fcfs_str += r"$^\dagger$"
        if not r_vga.sla_met:
            vga_str += r"$^\dagger$"

        saved_str = (f"$-${saved}" if saved > 0
                     else "---")
        money_str = (f"\\${saved_money:,.0f}"
                     if saved_money > 0 else "---")
        util_str  = f"{r_fcfs.utilization_pct:.0f}\\%"

        # Bold the rows where savings occur
        if saved > 0:
            row = (f"\\textbf{{{lam}}} & "
                   f"\\textbf{{{fcfs_str}}} & "
                   f"\\textbf{{{vga_str}}} & "
                   f"\\textbf{{{saved_str}}} & "
                   f"\\textbf{{{money_str}}} & "
                   f"\\textbf{{{util_str}}} \\\\")
        else:
            row = (f"{lam} & {fcfs_str} & {vga_str} & "
                   f"{saved_str} & {money_str} & "
                   f"{util_str} \\\\")
        lines.append(row)

    lines.append(r"\midrule")

    # Summary row
    mu_fcfs = EMPIRICAL_MU[("opt-1.3b", "fcfs")]
    mu_vga  = EMPIRICAL_MU[("opt-1.3b", "value_greedy_aging")]
    lines.append(
        r"\multicolumn{6}{l}{\scriptsize "
        r"$^\dagger$SLA not met. "
        r"\fcfs\ $\mu_{\text{eff}}$ = "
        f"{mu_fcfs:.3f}\\,rps; "
        r"\vga\ $\mu_{\text{eff}}$ = "
        f"{mu_vga:.3f}\\,rps. "
        r"Savings window: "
        f"{mu_fcfs:.1f}--{mu_vga:.1f}\\,rps."
        r"}"
    )
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table*}")
    return "\n".join(lines)


if __name__ == "__main__":
    run_analysis()
